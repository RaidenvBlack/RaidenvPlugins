$ollama = "J:\llama\ollama.exe"

if (Test-Path $ollama) {
    Write-Host "✅ Starte Ollama von $ollama" -ForegroundColor Green
    Start-Process "cmd.exe" -ArgumentList "/k `"$ollama run llama3.2`""
} else {
    Write-Host "❌ ollama.exe wurde nicht gefunden unter: $ollama" -ForegroundColor Red
}
